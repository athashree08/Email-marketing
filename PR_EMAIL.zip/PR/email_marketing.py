import os
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import google.generativeai as genai
from datetime import datetime, timedelta
import schedule
from dotenv import load_dotenv

load_dotenv("config.env")  # Load environment variables from .env


# Fetch API key and email credentials from environment variables
gemini_api_key = os.getenv("GEMINI_API_KEY")
email_address = os.getenv("EMAIL_ADDRESS")
email_password = os.getenv("EMAIL_PASSWORD")

print(f"GEMINI_API_KEY: {gemini_api_key}")
print(f"EMAIL_ADDRESS: {email_address}")
print(f"EMAIL_PASSWORD: {email_password}")


if not gemini_api_key or not email_address or not email_password:
    raise ValueError("Missing API key or email credentials. Set them as environment variables.")

# Configure Gemini API
genai.configure(api_key=gemini_api_key)

# Email configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

def generate_email_content(event_name, recipient_name, event_details, call_to_action):
    """
    Uses Gemini AI to generate a personalized email for event promotion.
    """
    prompt = f"""
    Write a compelling email for {recipient_name} about {event_name}. Include the details: {event_details}.
    End with a strong call to action: {call_to_action}.
    """
    
    model = genai.GenerativeModel("models/gemini-1.5-pro-latest")
    response = model.generate_content(prompt)
    
    if response and hasattr(response, 'text'):
        return response.text
    else:
        return "Error: Could not generate email content."

def send_email(to_email, subject, body):
    """Sends an email using SMTP."""
    msg = MIMEMultipart()
    msg['From'] = email_address
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(email_address, email_password)
        server.sendmail(email_address, to_email, msg.as_string())
        server.quit()
        print(f"Email sent to {to_email}")
    except Exception as e:
        print(f"Failed to send email: {e}")

def send_bulk_emails(email_list, subject, body):
    """Sends an email to multiple recipients."""
    for email in email_list:
        send_email(email, subject, body)
        time.sleep(1)  # Prevent spamming servers

def schedule_bulk_emails(email_list, subject, body, send_time):
    """Schedules an email to be sent at a later time to multiple recipients."""
    def job():
        send_bulk_emails(email_list, subject, body)
    
    schedule.every().day.at(send_time).do(job)
    print(f"Scheduled emails to {', '.join(email_list)} at {send_time}")

# Ask for scheduling before user input
decision = input("Do you want to schedule emails? (yes/no): ")
if decision.lower() == "yes":
    schedule_time = input("Enter time in HH:MM format (24-hour clock): ")
    is_scheduled = True
else:
    is_scheduled = False

# Get user input
event_name = input("Enter the event name: ")
recipient_name = input("Enter recipient's name: ")
event_details = input("Enter event details: ")
call_to_action = input("Enter the call-to-action (e.g., 'Register now!'): ")

# Generate AI-powered email content
email_body = generate_email_content(event_name, recipient_name, event_details, call_to_action)

# Print the email for preview
print("\nGenerated Email:\n")
print(email_body)

# Ask for recipient emails
to_emails = input("\nEnter recipient emails (comma-separated): ").split(',')
subject = f"You're Invited: {event_name}!"

if is_scheduled:
    schedule_bulk_emails(to_emails, subject, email_body, schedule_time)
    while True:
        schedule.run_pending()
        time.sleep(60)
else:
    send_bulk_emails(to_emails, subject, email_body)
